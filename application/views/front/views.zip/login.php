<style>
	.pin{
		height: 45px;
		width: 45px;
		font-size: 18px !important;
		text-align: center;		
	}
</style>
<div class="page-content header-clear-medium">
	<div class="card card-style" style="margin-top: 100px;">
		<div class="content" id="phoneNumber">
			<div class="text-center mb-3"><img src="<?= base_url('docs/Referral-Logo.png');?>" style="width:100px;height:auto"></div>
			<!-- <p class="font-600 color-highlight mb-n1">Let's start</p> -->
			<h1 class="font-30">Sign In</h1>
			<p>Enter your credentials below to sign into your account.</p>
			<form id="login" method="post" role="form" data-toggle="validator" >
			
				<div class="input-style has-icon input-style-1 input-required">
					<i class="input-icon fa fa-phone"></i>
					<!-- <span>Username</span> -->
					<em></em>
					<input class="form-control" name="email" type="text" id="emailPhone" required="" placeholder="Enter your registered phone number">
				</div> 
				<!-- <div class="input-style has-icon input-style-1 input-required">
					<i class="input-icon fa fa-lock"></i>
					<span>Password</span>
					<em>(required)</em>
					<input type="password" id="password" name="password" class="form-control" placeholder="Enter your password">
				</div> --> 
				
				<input type="submit" name="btn-login" id="signInBtn" class="btn btn-full btn-l font-600 font-13 gradient-highlight mt-4 rounded-s" value="Sign In"/>
				<div id="recaptcha-container"></div>
				<!-- <div class="row pt-3 mb-3">
					<div class="col-6 text-left">
						<a href="page-forgot-1.html" class="color-highlight">Forgot Password?</a>
					</div>
					<div class="col-6 text-right">
						<a href="page-signup-1.html" class="color-highlight">Create Account</a>
					</div>
				</div> -->
				<div class="divider"></div>
				
				<!-- <div class="text-center">
					<a href="#" class="icon icon-xs rounded-xl bg-facebook"><i class="fab fa-facebook"></i></a>
					<a href="#" class="icon icon-xs rounded-xl bg-twitter"><i class="fab fa-twitter"></i></a>
					<a href="#" class="icon icon-xs rounded-xl bg-google"><i class="fab fa-google"></i></a>
				</div> -->
			</form>
		</div>

		<div class="content" id="verificationCode" style="display: none;">
			<div class="text-center mb-3"><img src="<?= base_url('docs/Referral-Logo.png');?>" style="width:100px;height:auto"></div>
			<!-- <p class="font-600 color-highlight mb-n1">Let's start</p> -->
			<h1 class="font-30">OTP Verification</h1>
			<p>Enter OTP send to your mobile number.</p>
			<!-- <form id="verifyOtp" method="post" role="form" data-toggle="validator" > -->
			
				<div class="row ml-3 mr-3 mb-0">
					<?php
					/* if($data['pin']==1)
					{
					?>
					<div class="col-12">
						<label class="color-highlight">Enter new pin</label>
					</div>	
					<?php 
					} */
					?>
					<div class="col-2 p-1">
						<div class="input-style input-style-2 input-required">
							<input class="pin" required name="one" id="codeBox1" type="number" maxlength="1" onkeyup="onKeyUpEvent(1, event)" onfocus="onFocusEvent(1)" onkeypress="if(this.value.length==1) return false";/>
							<em></em>
						</div>         
					</div>
					<div class="col-2 p-1">
						<div class="input-style input-style-2 input-required">
							<input class="pin" required name="two" id="codeBox2" type="number" maxlength="1" onkeyup="onKeyUpEvent(2, event)" onfocus="onFocusEvent(2)" onkeypress="if(this.value.length==1) return false";/>
							<em></em>
						</div>         
					</div>
					<div class="col-2 p-1">
						<div class="input-style input-style-2 input-required">
							<input class="pin" required name="three" id="codeBox3" type="number" maxlength="1" onkeyup="onKeyUpEvent(3, event)" onfocus="onFocusEvent(3)" onkeypress="if(this.value.length==1) return false";/>
							<em></em>
						</div>         
					</div>
					<div class="col-2 p-1">
						<div class="input-style input-style-2 input-required">
							<input class="pin" required name="four" id="codeBox4" type="number" maxlength="1" onkeyup="onKeyUpEvent(4, event)" onfocus="onFocusEvent(4)" onkeypress="if(this.value.length==1) return false";/>
							<em></em>
						</div>         
					</div>
					<div class="col-2 p-1">
						<div class="input-style input-style-2 input-required">
							<input class="pin" required name="five" id="codeBox5" type="number" maxlength="1" onkeyup="onKeyUpEvent(5, event)" onfocus="onFocusEvent(5)" onkeypress="if(this.value.length==1) return false";/>
							<em></em>
						</div>         
					</div>
					<div class="col-2 p-1">
						<div class="input-style input-style-2 input-required">
							<input class="pin" required name="six" id="codeBox6" type="number" maxlength="1" onkeyup="onKeyUpEvent(6, event)" onfocus="onFocusEvent(6)" onkeypress="if(this.value.length==1) return false";/>
							<em></em>
						</div>         
					</div>
				</div>
				<div class="form-group text-center" ><span id="timerFP"></span>
					<div>
						<span id="resendOtpFP" class="font-13" name="btn-login" style="display:none;color: blue;text-decoration: underline;cursor: pointer;" >Resend OTP</span>		
					</div>
				</div>
				<input type="hidden" id="cus_id"  />
				<input type="button" name="btn-login" id="codeVerify" class="btn btn-full btn-l font-600 font-13 gradient-highlight mt-4 rounded-s" value="Verify Code"/>
				
				<div class="divider"></div>
				
			<!-- </form> -->
		</div>
	</div>
</div>
<script>
	
	$(document).ready(function(){

		$("#login").on('submit',function(r){
			r.preventDefault();
			var number = $("#emailPhone").val();
			$.ajax({
				type: "POST",
				url: '<?php echo base_url() ?>front/Authentication/login_check',
				data: $("#login").serialize(),
				dataType: 'json',
				success: function(data) {
					if (data.status == 'success') {
						$("#login").get(0).reset();

						window.recaptchaVerifier = new firebase.auth.RecaptchaVerifier('recaptcha-container', {
						'size': 'invisible',
						'callback': (response) => {
							// reCAPTCHA solved, allow signInWithPhoneNumber.
							onSignInSubmit();
						}
						});

						firebase.auth().signInWithPhoneNumber(number, window.recaptchaVerifier).then(function(confirmationResult) {
							//s is in lowercase
							window.confirmationResult = confirmationResult;
							coderesult = confirmationResult;
							// console.log(coderesult); // after send phone number otp response
							success_message('Success',"Message sent successfully to your registered mobile number");
							$("#cus_id").val(data.cusData.cus_id);
							$("#phoneNumber").hide();
							$("#verificationCode").show();
							
						}).catch(function(error) {
							error_message('',error.message);
						});

						// success_message('', data.msg);
					} else {
						error_message('', data.msg);
					}
				},
				error: function() {
					error_message('', data.msg);
				}
			});
		});
	
		$("#codeVerify").on('click',function(q){
			q.preventDefault();
			var one = document.getElementById('codeBox1').value;
			var two = document.getElementById('codeBox2').value;
			var three = document.getElementById('codeBox3').value;
			var four = document.getElementById('codeBox4').value;
			var five = document.getElementById('codeBox5').value;
			var six = document.getElementById('codeBox6').value;
			var cusId = $("#cus_id").val();
			var durl ='';
			var code = one+two+three+four+five+six;

			coderesult.confirm(code).then(function(result) {
				// success_message("","Successfully verified");
				$.ajax({
					type: "POST",
					url: '<?php echo base_url() ?>/front/Authentication/redirect_db/'+cusId,
					// data: $("#store-commission").serialize(),
					dataType: 'json',
					success: function(data) {
						if (data.status == 'success') {
							confirm_message("Success","Your Verification code has verified",data.url);
						} else {
							confirm_message("oops","Customer not registered with us",data.url);
						}
					},
					error: function() {
						error_message('', 'Something went wrong. Please try again');
					}
				});

				var user = result.user;
				// console.log(user); // after phone number verified response

			}).catch(function(error) {
				error_message('Error',error.message);
			});
		});
	});
</script>


