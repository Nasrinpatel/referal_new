<div class="content-page">
	<div class="card card-style">
		<div class="content">
			
			<!-- start page title -->
			<div class="row">
				<div class="col-12">
					<a type="button" href="<?=base_url('front/User')?>" class="btn btn-sm  mb-3 rounded-0 text-uppercase font-700 shadow-s btn btn-primary" style="float:right;" >Back</a>
					<h4>Edit User</h4>
				</div>
			</div>     
			<!-- end page title --> 
			
			<div class="content">
				<form action="<?= base_url('front/User/update/').$ud->user_id ?>" id="" method="post" role="form" enctype="multipart/form-data" data-toggle="validator" >
					<input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?=$this->security->get_csrf_hash()?>" />
					
					<div class="input-style has-borders no-icon input-style-always-active">
						<label for="customerName" class="color-highlight">Name</label>
						<input type="text" class="form-control" name="name" id="customerName" value="<?= set_value('name',$ud->name)?>"/>
						<?=  form_error('name');?>
					</div>
					<div class="input-style has-borders no-icon input-style-always-active">
						<label for="customerName" class="color-highlight">Role Type</label>
						<select id="selectize-select" name="ur_id">
							<option data-display="Select">--select--</option>
							<?php
							if (count($role)) :
								foreach ($role as $cus) :
								?> 
									<option <?php if (set_value('ur_id',$ud->ur_id)== $cus['ur_id']) {echo "selected";} ?> 
											value="<?=$cus['ur_id']?>"><?= $cus['role_name']?></option>
								<?php
								endforeach;
							endif; ?>
						</select>
						<?=  form_error('ur_id');?>
					</div>
					<div class="input-style has-borders no-icon input-style-always-active">
						<label for="customerNumber" class="color-highlight">Mobile Number</label>
						<input type="text" pattern="\d*" class="form-control" onkeypress="return ((event.charCode >= 48 && event.charCode <= 57))" name="phone_no" maxlength="10" id="customerNumber" value="<?= set_value('phone_no',$ud->phone_no)?>"/>
						<?=  form_error('phone_no');?>
					</div>
					<div class="input-style has-borders no-icon input-style-always-active">
						<label for="customerEmail" class="color-highlight">Email ID</label>
						<input type="email" id="customerEmail" name="email" class="form-control" name="email" value="<?= set_value('email',$ud->email)?>"/>
						<?=  form_error('email');?>
					</div>
					
					<input type="submit" class="btn btn-full btn-m gradient-highlight rounded-s font-13 font-600" value="Update">	
				</form>
			</div>
		</div>
	</div>
</div>
