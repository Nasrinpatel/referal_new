<div id="preloader"><div class="spinner-border color-highlight" role="status"></div></div>
