<script type="text/javascript" src="<?= base_url('assets/front/') ?>scripts/bootstrap.min.js"></script>
<script type="text/javascript" src="<?= base_url('assets/front/') ?>scripts/custom.js"></script>

<!-- for use multi select-->
<script src="<?= base_url()?>assets/front/select2/js/select2.min.js"></script>
<!--for use CKeditor js -->
<script type="text/javascript" src="<?= base_url('assets/front/') ?>ckeditor/ckeditor.js"></script>
<script type="text/javascript" src="<?= base_url('assets/front/') ?>ckeditor/build-config.js"></script>
<!-- <script type="text/javascript" src="<?= base_url('assets/front/') ?>ckeditor/styles.js"></script> -->
<!-- <script type="text/javascript" src="<?= base_url('assets/front/') ?>ckeditor/adapters/jquery.js"></script> -->
