<div id="footer-bar" class="footer-bar-6">
	<a href="<?= base_url('front/Company') ?>"><i class="fa fa-layer-group"></i><span>Company</span></a>
	<a href="<?= base_url('front/Customer') ?>"><i class="fa fa-file"></i><span>Customer</span></a>
	<a href="<?= base_url('front/Dashboard') ?>" class="circle-nav active-nav"><i class="fa fa-home"></i><span>Welcome</span></a>
	<a href="<?= base_url('front/User') ?>"><i class="fa fa-image"></i><span>User</span></a>
	<a href="<?= base_url('front/User_role') ?>"><i class="fa fa-user"></i><span>User Role</span></a> 
</div>
