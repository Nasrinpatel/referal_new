<div class="page-content pb-3">
	<div>
		<div class="content" style="margin-bottom: 20% !important;">
		<h4>Commission History</h4>
		<div class="divider divider-margins"></div>
		<!-- <div class="row mb-0">
			<div class="col-12">
				<a href="#" style="float: right;" data-menu="popup-commission" class="btn btn-sm  mb-3 rounded-0 text-uppercase font-700 shadow-s bg-magenta-dark">Add Commission</a>
			</div>
		</div>

		<div class="divider divider-margins"></div> -->

		
		
		<div>
			<div class="content">
				<div class="has-borders no-icon input-style-always-active mb-4">
					<label for="refer_by" class="color-highlight">Customer Name</label>
					<select name="cus_id" class="form-control customer_referral" id="comCusId">
						<option value="" selected>----Select----</option>
						<?php
						foreach ($cusData as $cr) { ?>
							<option <?php if (set_value('cus_id')== $cr['cus_id']) {echo "selected"; }?>
									value="<?= $cr['cus_id'] ?>"><?php echo $cr['customer_phone_no']." : ".$cr['customer_name']?>
							</option>
						<?php }
						?>
					</select>
				</div>
				<div class="clearfix mb-3"></div>
				<table id="commissionHisTable" class="table table-borderless text-center rounded-sm shadow-l responsive mobile-l display nowrap">
					<thead>
						<tr class="bg-blue-dark">
							<th>Amount</th>
							<th>Date</th>
						</tr>
					</thead>
					<tbody id="commissionHisData">
						<?php
						$countNo = 0;
						foreach ($comData as $comL)
						{
							$countNo++;
							?>
							<tr>
								<td><?= $comL['com_amount'] ?></td>
								<td><?= date_format(date_create($comL['created']),'d-M-Y') ?></td>
								<!-- <td><?php if($comL['referral_name'] != ''){ echo $comL['referral_name']; }else{ echo "-";}?></td>
								<td>
									<div>
										<div class="dropdown">
											<a class="btn bg-green-dark dropdown-toggle ps-1 pe-1 font-10" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
												Action
											</a>
											<ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
												<li><a href="" class="commission_edit dropdown-item" data-comid="<?=$comL['com_id']?>">Edit</a></li>
												<li><a class="dropdown-item" href="<?= base_url('front/Commission/delete/'.$comL['com_id']) ?>">Delete</a></li>
											</ul>
										</div>
									</div>
								</td> -->
							</tr>
							<?php 
						} ?>
					</tbody>
				</table>
			</div>
		</div>
	</div> <!-- content -->
</div>
<script>
	$(document).ready( function () {
		$('#commissionHisTable').DataTable({
			responsive: true
		});

		$("#comCusId").on('change',function(x){
			x.preventDefault();
			var customerID = $(this).val();
			$.ajax({
				type: 'ajax',
				url: '<?php echo base_url() ?>front/Commission/all_commission/'+customerID,
				async: false,
				dataType: 'json',
				success: function(data){
					var html = '';
					var i; var j =1;
					for(i=0; i<data.length; i++){	
						html +='<tr>'+
									'<td>'+data[i].com_amount+'</td>'+
									'<td>'+formatDate(data[i].created)+'</td>'+
									/* '<td>'+
										'<div>'+
											'<div class="dropdown">'+
												'<a class="btn bg-green-dark dropdown-toggle ps-1 pe-1 font-10" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">'+
													'Action'+
												'</a>'+
												'<ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">'+
													'<li><a class="commission_edit dropdown-item" data-comid="'+data[i].com_id+'">Edit</a></li>'+
													'<li><a class="dropdown-item" href="<?php // base_url('front/Commission/delete/')?>'+data[i].com_id+'">Delete</a></li>'+
												'</ul>'+
											'</div>'+
										'</div>'+
									'</td>'+ */
								'</tr>';
						j++;		
					}
					$('#commissionHisTable').DataTable().destroy();
					$('#commissionHisData').html(html);
					$('#commissionHisTable').DataTable({
						responsive : true
					});
				},
				error: function(){
					alert('Could not get Data from Database');
				}
			});
			
		});
	});
</script>
