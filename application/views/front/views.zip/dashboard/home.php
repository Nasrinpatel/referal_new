<div class="page-content">
	<div class="content">
		<div class="row mb-0">
			<div class="col ps-2">
				<a href="<?= base_url('front/Company') ?>" data-back-button class="card card-style rounded-m ms-0  p-3 mb-3">
					<i class="fa fa-users color-red-light font-40 icon-50"></i>
					<h5 class="pt-3">Company - <?= count_row('tb_company_master') ?></h5>
				</a>
			</div>
			<div class="col ps-2">
				<a href="<?= base_url('front/Customer') ?>" data-back-button class="card card-style rounded-m ms-0  p-3 mb-3">
					<i class="fa fa-user color-yellow-light font-40 icon-50"></i>
					<h5 class="pt-3">Customer - <?= count_row('tb_customer') ?></h5>
				</a>
			</div>
		</div>
		<!-- <div class="row mb-0">
			<div class="col ps-2">
				<a href="<?php // base_url('front/Quotation') ?>" data-back-button class="card card-style rounded-m ms-0  p-3 mb-3">
					<i class="fa fa-user color-yellow-light font-40 icon-50"></i>
					<h5 class="pt-3">Quotation - <?php // count_row('tb_quotation') ?></h5>
				</a>
			</div>
		</div> -->
	</div>
</div>
