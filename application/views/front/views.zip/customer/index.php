<div class="page-content pb-3">
	<div>

		<div class="content" style="margin-bottom: 20% !important;">
		<h4>Manage Customer</h4>
		<div class="divider divider-margins"></div>
		<div class="row mb-0">
			<div class="col-12">
				<a href="<?= base_url('front/Customer/add') ?>" style="float: right;" class="btn btn-sm  mb-3 rounded-0 text-uppercase font-700 shadow-s bg-magenta-dark">Add Customer</a>
			</div>
		</div>

		<div class="divider divider-margins"></div>

		<div>
			<div class="content" id="tab-group-2">
				<div class="tab-controls tabs-small tabs-rounded">
					<a href="<?= base_url('front/Customer/index')?>" data-tab="tab-1" class="gradient-magenta">Default</a>
					<a href="<?= base_url('front/Customer/convertCus')?>" data-tab="tab-2" class="gradient-yellow">Convert</a>
				</div>
				<div class="clearfix mb-3"></div>
				<table id="customerDetTable" class="table table-borderless text-center rounded-sm shadow-l responsive mobile-l display nowrap">
					<thead>
						<tr class="bg-blue-dark">
							<th>Customer Name</th>
							<th>Customer Code</th>
							<th>Mobile Number</th>
							<th>Email</th>
							<th>Created By</th>
							<th>Created On</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
						<?php
						$countNo = 0;
						foreach ($cusData as $cusL)
						{
							$countNo++;
							?>
							<tr>
								<td><?= $cusL['customer_name'] ?></td>
								<td><?= $cusL['customer_code'] ?></td>
								<td><?= $cusL['customer_phone_no'] ?></td>
								<td><?= $cusL['customer_email'] ?></td>
								<td><?= $cusL['name'] ?></td>
								<td><?= date_format( date_create($cusL['created']),'d-m-Y') ?></td>
								<td>
									<div>
										<div class="dropdown">
											<a class="btn bg-green-dark dropdown-toggle ps-1 pe-1 font-10" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
												Action
											</a>
											<ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
												<li><a class="dropdown-item" href="<?= base_url('front/Customer/edit/'.$cusL['cus_id']) ?>">Edit</a></li>
												<li><a class="dropdown-item" href="<?= base_url('front/Customer/delete/'.$cusL['cus_id']) ?>">Delete</a></li>
												<li><a class="dropdown-item" href="<?= base_url('front/Customer/view/'.$cusL['cus_id']) ?>">View</a></li>
												<li><a class="popup-convert dropdown-item" href="#" data-cusid="<?=$cusL['cus_id']?>">Convert</a></li>
											</ul>
										</div>
									</div>
								</td>
							</tr>
							<?php 
						} ?>
					</tbody>
				</table>
			</div>
		</div>
	</div> <!-- content -->
</div>
<script>
	$(document).ready( function () {
		$('#customerDetTable').DataTable({
			responsive: true,
			columnDefs: [
				{ responsivePriority: 1, targets: 0 },
				{ responsivePriority: 3, targets: 1},
				{ responsivePriority: 2, targets: 6}
        	]
		});
	});
</script>
