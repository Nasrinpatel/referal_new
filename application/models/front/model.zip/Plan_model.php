<?php

class Plan_model extends CI_Model{

	public function __construct(){
       
		$this->user_id = $this->session->userdata('user_id');
		parent::__construct();
    }//__construct

	public function all()
	{
		return $this->db->select('*')->get('tb_plan')->result_array();
	}

	public function add($data)
	{
		
		$this->db->insert('tb_plan',['ref_con_fee'=> $data['ref_con_fee']]);
		$plan_id = $this->db->insert_id();

		if(!empty($data['ref_fee_per_wise'])){
			foreach ($data['ref_fee_per_wise'] as $key => $value) {
				if(!empty($value)){ 
					$this->db->insert('tb_plan_det',[
									'ref_fee_per_wise' =>$value,
									'plan_id' =>$plan_id,
									'ref_days_fromTo' =>$data['ref_days_fromTo'][$key]
								]);
				}
			}
		}
		return true;
	}

	public function update($plan_id,$data)
	{
		
		$this->db->where('plan_id',$plan_id)
				->update('tb_plan',['ref_con_fee'=> $data['ref_con_fee']]);

		$before_plan =  $this->db->where('plan_id',$plan_id)->get('tb_plan_det')->num_rows();
		$after_plan = count($data['ref_fee_per_wise']);

		if(!empty($data['ref_fee_per_wise']) && ($after_plan > $before_plan || $after_plan < $before_plan)){
				// echo "after_plan".$after_plan."> before_plan".$before_plan; exit;
			$this->db->where('plan_id',$plan_id)->delete('tb_plan_det');
			foreach ($data['ref_fee_per_wise'] as $key => $value) {
				if(!empty($value)){ 
					$this->db
					//where('plan_id',$plan_id)
							->insert('tb_plan_det',[
									'ref_fee_per_wise' =>$value,
									'plan_id' =>$plan_id,
									'ref_days_fromTo' =>$data['ref_days_fromTo'][$key]
								]);
				}
			}
		}
		return true;
	}

	public function edit_pl($plan_id)
	{
		return $this->db->where('plan_id',$plan_id)->get('tb_plan')->row_array();
	}

	public function edit_pl_det($plan_id)
	{
		return $this->db->where('plan_id',$plan_id)->get('tb_plan_det')->result_array();
	}

	public function everyMothCronGetRefCal()
	{
		
	}
}
?>
