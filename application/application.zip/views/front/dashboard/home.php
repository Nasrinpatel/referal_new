<?php if(get_ut_role($this->session->userdata('user_type')) == 'Admin'){?>
	<div class="page-content">
		<div class="content">
			<div class="row mb-0">
				<div class="col ps-2">
					<a href="<?= base_url('front/Company') ?>" data-back-button class="card card-style rounded-m ms-0  p-3 mb-3">
						<i class="fa fa-users color-red-light font-40 icon-50"></i>
						<h5 class="pt-3">Company - <?= count_row('tb_company_master') ?></h5>
					</a>
				</div>
				<div class="col ps-2">
					<a href="<?= base_url('front/Customer') ?>" data-back-button class="card card-style rounded-m ms-0  p-3 mb-3">
						<i class="fa fa-user color-yellow-light font-40 icon-50"></i>
						<h5 class="pt-3">Customer - <?= count_row('tb_customer') ?></h5>
					</a>
				</div>
			</div>
			<!-- <div class="row mb-0">
				<div class="col ps-2">
					<a href="<?php // base_url('front/Quotation') ?>" data-back-button class="card card-style rounded-m ms-0  p-3 mb-3">
						<i class="fa fa-user color-yellow-light font-40 icon-50"></i>
						<h5 class="pt-3">Quotation - <?php // count_row('tb_quotation') ?></h5>
					</a>
				</div>
			</div> -->
		</div>
	</div>
<?php }else{?>
	<div class="page-content">
		<div class="col-12">
			<h2 class="text-center">Current month referral list</h2>
		</div>
		<div class="content">
			<div class="clearfix mb-3"></div>
				<table id="CusRefHisTable" class="table table-borderless text-center rounded-sm shadow-l responsive mobile-l display nowrap">
					<thead>
						<tr class="bg-blue-dark">
							<th>Date</th>
							<th>Referral Name</th>
						</tr>
					</thead>
					<tbody>
						<?php 
						$countNo = 0;
						foreach ($refList as $rl)
						{
							$countNo++;
							?>
							<tr>
								<td><?=date_format(date_create($rl['refer_date']),'d-m-Y')?></td>
								<td><?=$rl['customer_name']?></td>
							</tr>
							<?php 
						} ?>
					</tbody>
				</table>
		</div>
	</div>
<?php }?>
<script>
	$(document).ready( function () {
		$('#CusRefHisTable').DataTable({
			responsive: true
		});
	});
</script>
