<link rel="stylesheet" type="text/css" href="<?= base_url('assets/front/') ?>styles/bootstrap.css">
<link rel="stylesheet" type="text/css" href="<?= base_url('assets/front/') ?>styles/style.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?= base_url('assets/front/') ?>fonts/css/fontawesome-all.min.css">
<!-- <link rel="manifest" href="_manifest.json"> -->
<link rel="apple-touch-icon" sizes="180x180" href="<?= base_url('docs/Referral-Logo.png') ?>">

<!-- for use multi selct -->
<link href="<?=base_url()?>assets/front/select2/css/select2.min.css" rel="stylesheet" />
<!-- <link href="<?= base_url(); ?>assets/front/select2/css/select2.min.css" rel="stylesheet" type="text/css" /> -->

<!-- for data table -->
<link href="<?= base_url(); ?>assets/front/styles/jquery.dataTables.min.css" rel="stylesheet" type="text/css" />
<link href="<?= base_url(); ?>assets/front/styles/responsive.dataTables.min.css" rel="stylesheet" type="text/css" />
<link href="<?= base_url(); ?>assets/front/styles/dataTables.bootstrap5.min.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="<?= base_url('assets/front/') ?>scripts/jquery-3.6.0.js"></script>

<!-- for use show sweet alert -->
<script type="text/javascript" src="<?= base_url('assets/front/') ?>scripts/sweetalert.min.js"></script>
<script type="text/javascript" src="<?= base_url('assets/front/') ?>scripts/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="<?= base_url('assets/front/') ?>scripts/dataTables.responsive.min.js"></script>
<script type="text/javascript" src="<?= base_url('assets/front/') ?>scripts/dataTables.bootstrap5.min.js"></script>
<script type="text/javascript" src="<?= base_url('assets/front/') ?>scripts/firebase.js"></script>
<script type="text/javascript">
	//for month show
	const consMonth = ["Jan","Feb","Mar","Apr","May","June","July","Aug","Sept","Oct","Nov","Dec"];
	function success_message(title,text){
		Swal.fire({
			title: title,
			text: text,
			icon: "success",
			button: "Okay!",
		});
	}
	function error_message(title,text){
		Swal.fire({
			title: title,
			text: text,
			icon: "error",
			button: "Okay!",
		});
	}

	function confirm_message(title,text,url){
		Swal.fire({
			title: title,
			text: text,
			icon: title,
			showCancelButton: false,
			confirmButtonColor: '#3085d6',
			// cancelButtonColor: '#d33',
			confirmButtonText: 'OK'
		}).then((result) => {
			/* if (result.isConfirmed) {
				Swal.fire(
				'Deleted!',	
				'Your file has been deleted.',
				'success'
				)
			} */
			window.location.reload(url);
		})
	}

	$(document).ready(function(){
		<?php if($this->session->flashdata('success')){ ?>
			success_message("<?= $this->session->flashdata('success_title') ?>","<?= $this->session->flashdata('success') ?>");
		<?php } ?>
		<?php if($this->session->flashdata('error')){ ?>
			error_message("<?= $this->session->flashdata('error_title') ?>","<?= $this->session->flashdata('error') ?>");
		<?php } ?>
		$('.js-example-basic-single').select2();
		$('.customer_referral').select2();

	});
	
	function close_popup(){
		var wrappers = document.querySelectorAll('.header, #footer-bar, .page-content');
		const activeMenu = document.querySelectorAll('.menu-active');
		for(let i=0; i < activeMenu.length; i++){activeMenu[i].classList.remove('menu-active');}
		for(let i=0; i < wrappers.length; i++){wrappers[i].style.transform = "translateX(-"+0+"px)"}
	}
	function open_popup(popup_id){
		document.getElementById(popup_id).classList.add('menu-active');
		document.getElementsByClassName('menu-hider')[0].classList.add('menu-active');
	}
	
	function formatDate(date) {
		var d = new Date(date),
			month = '' + (d.getMonth() + 1),
			day = '' + d.getDate(),
			year = d.getFullYear();

		if (month.length < 2) month = '0' + month;
		if (day.length < 2) day = '0' + day;

		return [day, month, year].join('-')
	}

	function formatDateModify(date,sep) {
		if(sep != 'M'){
		var d = new Date(date),
			month = '' + consMonth[d.getMonth()],
			day = '' + d.getDate(),
			year = d.getFullYear();
			if (day.length < 2) day = '0' + day;
		}
		
		// if (month.length < 2) month = '0' + month;
		
		if(sep == 'd'){
			return [day]
		}else if(sep == 'm'){
			return [month]
		}else if(sep == 'M'){
			var d = new Date(date),
			month = '' + (d.getMonth()+1),
			day = '' + d.getDate(),
			year = d.getFullYear();
			return [month]
		}else{
			return [year]
		}
	}


	//load firebase
	var firebaseConfig = {
							appId: "1:97120346727:web:ec737c9efc5a7a64166ac2",
							apiKey: "AIzaSyBHSMA4nUyq1XDuQjuw1kSEnZiMRARmGGA",
							authDomain: "referral-42a0b.firebaseapp.com",
							projectId: "referral-42a0b",
							storageBucket: "referral-42a0b.appspot.com",
							messagingSenderId: "97120346727",
							// measurementId: "G-CCJ2B0YHR3"s
						};

    // Initialize Firebase
    firebase.initializeApp(firebaseConfig);
    firebase.analytics();

	function getCodeBoxElement(index) {
        return document.getElementById('codeBox' + index);
	}
	function onKeyUpEvent(index, event) {
		const eventCode = event.which || event.keyCode;
		if (getCodeBoxElement(index).value.length === 1) {
			if (index !== 6) {
				getCodeBoxElement(index+ 1).focus();
			} else {
				getCodeBoxElement(index).blur();
			// Submit code
				console.log('submit code ');
			}
		}
		if (eventCode === 8 && index !== 1) {
			getCodeBoxElement(index - 1).focus();
		}
	}
	function onFocusEvent(index) {
		for (item = 1; item < index; item++) {
			const currentElement = getCodeBoxElement(item);
			if (!currentElement.value) {
				currentElement.focus();
				break;
			}
		}
	}
	$(document).ready(function(){
		// CKEDITOR.disableAutoInline = true;
		// Replace the <textarea id="ckeditor"> with a CKEditor
		// instance, using default configuration.
		CKEDITOR.replace( 'editor1');
		
		/* setInterval(() => {
			$('a:not([href])').each(function(){
				$(this).attr('href','#');
			});
		}, 500);
		
		$('a[href="#"]').click(function(){
			$('a:not([href])').each(function(){
				$(this).attr('href','#');
			});
		}) */
	});
</script>
