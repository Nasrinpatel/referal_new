<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	if(!function_exists('count_row'))
	{
		function count_row($table)
		{
			$ci =& get_instance();
			return  $ci->db->select('*')->get($table)->num_rows();
		}
	}

	//for get data using where condition
	if(!function_exists('get_data'))
	{
		function get_data($table,$rowName,$id)
		{
			$ci =& get_instance();
			return  $ci->db->select('*')->where($rowName,$id)->get($table)->row();
		}
	}

	// for inquiry number generate like 00001/mm/YY 
	if(!function_exists('inquiry_auto_gen_num'))
	{
		function inquiry_auto_gen_num()
		{
			$ci =& get_instance();
			$inquiryCode=$ci->db 
							->select(['inq_code'])
							->from('inquiry_master') 
							->order_by('inq_code',"DESC")
							->get();
			$InqCode=$inquiryCode->row();	
			if($inquiryCode->num_rows()==0){
				$CusCode="00001"."/".date('m')."/".date('y'); // Starting Number
			}
			else
			{
				$number=preg_replace('/\/(\d{2})\/(\d{2})\z/','',$InqCode->inq_code);
				
				if($number >= 00001)
				{
					$CusCode = $number + 1;
					$CusCode= str_pad($CusCode,5,0,STR_PAD_LEFT)."/".date('m')."/".date('y');
				}
				else{		
					// echo "else";	
					$CusCode="00001"."/".date('m')."/".date('y'); // Starting Number
				}   
			}
			return $CusCode;
		}
	}

	//for all question count if international than skip
	if(!function_exists('all_question_count'))
	{
		function all_question_count($im_id,$inq_status,$is_international_evt)
		{
			$ci =& get_instance();
			
			//stage master id wise find question category
			$queCat = $ci->db->where('sm_ids like("%'.$inq_status.'%")')->get('category_master')->result_array();

			$queCount=0;
			foreach($queCat as $qc){
				if($is_international_evt == 1){
					// echo "if/";
					$ci->db->where('is_international IN (0,'.$is_international_evt.')');
					$ci->db->where('category_id',$qc['category_id']);	
				}else{
					// echo "else/";
					$ci->db->where('is_international IN (0)');
					$ci->db->where('category_id',$qc['category_id']);	
				}
				$question = $ci->db->get('question_master')->num_rows();
				$queCount = $queCount + $question;
			}
			// echo $queCount; 
			return $queCount;
		}
	}

	//for all answer count if international than skip
	if(!function_exists('all_answer_count'))
	{
		function all_answer_count($im_id)
		{
			$ci =& get_instance();	
			$is_international_evt=$ci->db 
									->select(['is_international_evt'])
									->where('im_id',$im_id)
									->get('inquiry_master')->row()->is_international_evt;	
			$ans=$ci->db->where('inquiry_id',$im_id)
						->group_by('question_id')
						->get('answer_master'); 
						
			if($is_international_evt == 1){
				$ansCount = $ans->num_rows();
			}else{		
				$answer = $ans->result_array();
				$ansCount=0;
				foreach($answer as $a)
				{	
					$chk=$ci->db->get_where('question_master',array('question_id'=>$a['question_id'],'is_international'=>0))->num_rows();
					if($chk > 0){
						$ansCount++;
					}
				}
			}
			// echo $ansCount; exit;
			return $ansCount;
		}
	}

	//for all sidebar stage wise count which inquiry in which stage
	if(!function_exists('sidebar_stage_count'))
	{
		function sidebar_stage_count($stage_name)
		{
			$ci =& get_instance();	
			
			$smdata = $ci->db->where('stage_name like "%'.$stage_name.'%"')->get('stage_master')->row();
			// echo $ci->db->last_query(); exit;
			if($smdata){
				$stageCount=$ci->db->where('inquiry_status',$smdata->sm_id)->get('inquiry_master')->num_rows();	
			}else{
				$stageCount = 0;
			}
			return $stageCount;
		}
	}

	// for all stage has dynamic show with sidebar or tab wise
	if(!function_exists('stageDynamic'))
	{
		function stageDynamic($tab,$sidebar)
		{
			$ci =& get_instance();	
			if($tab == 1){
				$ci->db->where('show_tab',$tab);
			}
			if($sidebar == 1){
				$ci->db->where('show_sidebar',$sidebar);
			}
			$list = $ci->db->get('stage_master')->result_array();
			
			return $list;
		}
	}

	// for inquiry action button question count category wise
	if(!function_exists('inq_action_que_count'))
	{
		function inq_action_que_count($isInternationalEvt,$catId)
		{
			$ci =& get_instance();	
			
			if($isInternationalEvt == 1){
				$ci->db->where('category_id',$catId);
				$ci->db->where('is_international IN(0,'.$isInternationalEvt.')');
				$count = $ci->db->get('question_master')->num_rows();
			}else{
				$ci->db->where('category_id',$catId);
				$ci->db->where('is_international IN(0)');
				$count = $ci->db->get('question_master')->num_rows();
			}
			
			return $count;
		}
	}

	// for inquiry action button question count category wise
	if(!function_exists('inq_action_ans_count'))
	{
		function inq_action_ans_count($im_id,$catId,$inquiry_status)
		{
			$ci =& get_instance();	
			$queryAns = $ci->db->where('inquiry_id',$im_id)
								->where('category_id',$catId)
								->group_by('question_id')
								->get('answer_master'); 

			if($inquiry_status == 1){
				$count_ans = $queryAns->num_rows();
			}else{
				$answer = $queryAns->result_array();
				$count_ans=0;
				foreach($answer as $a)
				{	
					$chk=$ci->db->get_where('question_master',array('question_id'=>$a['question_id'],'is_international'=>0,'category_id' => $catId))->num_rows();
					if($chk > 0){
						$count_ans++;
					}
				}
			}
			return $count_ans;
		}
	}

	//for cudtomer or user mobile number masking
	if(!function_exists('numberMask'))
	{
		function numberMask($num)
		{
			return substr( $num, 0, 2 ) // Get the first two digits
					.str_repeat( '*', ( strlen( $num ) - 4 ) ) // Apply enough asterisks to cover the middle numbers
					.substr( $num, -2 ); // Get the last two digits
		}
	}

	//for customer mobile number check in db exist or not
	if(!function_exists('cusMobValidation'))
	{
		function cusMobValidation($CusNum)
		{
			$ci =& get_instance();	
			$nc = $ci->db->where('customer_phone_no',$CusNum)->get('tb_customer')->num_rows();
			
			if($nc == 0){
				return true;//mob number is unique
			}else{
				return false;//mob is already register with us
			}
		}
	}

	//get usertype through role name
	if(!function_exists('get_ut_role'))
	{
		function get_ut_role($userType)
		{
			$ci =& get_instance();	
			return $ci->db->where('role_id',$userType)->get('tb_user_role')->row()->role_name;
		}
	}
?>
